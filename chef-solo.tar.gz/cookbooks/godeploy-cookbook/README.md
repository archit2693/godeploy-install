# Godeploy-cookbook

The cookbook installs the rails application ritik02/Deploy.
It installs Deploy app on a ubuntu machine, it gets all dependencies and install them.

